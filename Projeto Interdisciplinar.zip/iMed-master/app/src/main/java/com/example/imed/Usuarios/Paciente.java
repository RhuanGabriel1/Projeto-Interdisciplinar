package com.example.imed.Usuarios;

public class Paciente extends Usuario {

    String cpf;

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }


}
